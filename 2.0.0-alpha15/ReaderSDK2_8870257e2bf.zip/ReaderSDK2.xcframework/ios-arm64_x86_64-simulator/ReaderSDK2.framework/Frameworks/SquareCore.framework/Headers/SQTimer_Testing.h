//
//  SQTimer_Testing.h
//  SquareCore
//
//  Created by Kyle Van Essen on 10/18/14.
//  Copyright (c) 2014 Square, Inc. All rights reserved.
//

#import <SquareCore/SQTimer.h>


@interface SQTimer ()

@property (nonatomic, strong) NSTimer *timer;

@end
