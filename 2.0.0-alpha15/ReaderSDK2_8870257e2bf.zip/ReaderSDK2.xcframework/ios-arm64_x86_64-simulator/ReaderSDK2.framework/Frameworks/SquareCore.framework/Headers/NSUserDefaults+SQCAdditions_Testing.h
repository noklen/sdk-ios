//
//  NSUserDefaults+SQCAdditions_Testing.h
//  Pods
//
//  Created by Brian Partridge on 3/31/17.
//
//

#import "NSUserDefaults+SQCAdditions.h"


@interface NSUserDefaults (SQCAdditionsTesting)

+ (void)SQ_resetSquareUserDefaults;

@end
