//
//  CSGen2AnalogSignalDecoderResult.h
//  CoreSwipe
//
//  Created by Scott Perry on 9/20/13.
//  Copyright (c) 2013 Square, Inc. All rights reserved.
//

#import "CSAnalogSignalDecoderResult.h"


@interface CSGen2AnalogSignalDecoderResult : CSAnalogSignalDecoderResult

@property (nonatomic, assign) BOOL decodeSucceeded;

@end
