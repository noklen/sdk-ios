#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wignored-attributes"
#pragma clang attribute push(__attribute__((objc_subclassing_restricted)), apply_to=any(objc_interface))
#define SWIFT_WARN_UNUSED_RESULT __attribute__((warn_unused_result))
#define RuntimeName(RUNTIMENAME) __attribute__((objc_runtime_name(RUNTIMENAME)))
#define Func(X) __attribute__((swift_name(X))) __attribute__((warn_unused_result))
#define DiscardableFunc(X) __attribute__((swift_name(X)))
#define SwiftName(X) __attribute__((swift_name(X)))
#define Enum(TYPE, CNAME, SNAME) NS_CLOSED_ENUM(TYPE, __attribute__((swift_name(SNAME))) CNAME)
#define SWIFT_UNAVAILABLE_MSG(msg) __attribute__((unavailable(msg)))
#define SWIFT_UNAVAILABLE __attribute__((unavailable))
# define OBJC_DESIGNATED_INITIALIZER __attribute__((objc_designated_initializer))
#define ErrorEnum(DOMAIN, CNAME, SNAME) NS_CLOSED_ENUM(NSInteger, __attribute__((ns_error_domain(DOMAIN))) __attribute__((swift_name(SNAME))) CNAME)

@class NSDate;
@class NSError;
@class NSNumber;
@class NSString;
@class SQRDCardInputMethods;
@class SQRDCardOnFilePaymentSource;
@class SQRDKeyedCardPaymentSource;
@class SQRDMoney;
@class SQRDPaymentParameters;
@class SQRDTheme;
@class UIColor;
@class UIFont;
@class UIViewController;
@protocol SQRDAlternatePaymentMethod;
@protocol SQRDAuthorizationManager;
@protocol SQRDAuthorizationStatusObservable;
@protocol SQRDAvailableCardInputMethodsObserver;
@protocol SQRDCard;
@protocol SQRDCardPaymentDetails;
@protocol SQRDLocation;
@protocol SQRDMoneyAmount;
@protocol SQRDPairingHandle;
@protocol SQRDPayment;
@protocol SQRDPaymentHandle;
@protocol SQRDPaymentManager;
@protocol SQRDPaymentManagerDelegate;
@protocol SQRDPaymentSource;
@protocol SQRDReaderBatteryStatus;
@protocol SQRDReaderConnectionFailureInfo;
@protocol SQRDReaderConnectionInfo;
@protocol SQRDReaderFirmwareInfo;
@protocol SQRDReaderInfo;
@protocol SQRDReaderManager;
@protocol SQRDReaderObserver;
@protocol SQRDReaderPairingDelegate;
@protocol SQRDSDKManager;

/// The Type  of Payment that is about to take place.
typedef Enum(NSInteger, SQRDAlternatePaymentMethodType, "AlternatePaymentMethodType") {
	/// Instructs the SDK to begin a payment for a keyed in credit card.
	SQRDAlternatePaymentMethodTypeKeyed,
	/// Instructs the SDK to charge a Card on File
	SQRDAlternatePaymentMethodTypeCardOnFile
};

/// OBJC_NAMESPACE
typedef Enum(NSInteger, __swift_namespace_Errors, "Errors") {
__ignore_me_Errors
};

/// Domain associated with errors relating to SQRDAuthorizationError
static NSString * _Nonnull const SQRDAuthorizationErrorDomain = @"ReaderSDK2API.Errors.Authorization";

/// Errors that occur when authorization fails.
typedef ErrorEnum(SQRDAuthorizationErrorDomain, SQRDAuthorizationError, "Errors.Authorization") {
	/// Reader SDK could not connect to the network.
	SQRDAuthorizationErrorNoNetwork = 0,
	/// Device is already authorized with a Square account.
	SQRDAuthorizationErrorAlreadyAuthorized,
	/// An unexpected error occurred. See the debug code and message for more information.
	SQRDAuthorizationErrorAlreadyInProgress,
	/// Authorization code has already been redeemed.
	SQRDAuthorizationErrorAuthorizationCodeAlreadyRedeemed,
	/// Authorization code has expired.
	SQRDAuthorizationErrorExpiredAuthorizationCode,
	/// Authorization code is invalid.
	SQRDAuthorizationErrorInvalidAuthorizationCode,
	/// Access token is invalid.
	SQRDAuthorizationErrorInvalidAccessToken,
	/// Access code is empty.
	SQRDAuthorizationErrorEmptyAccessToken,
	/// LocationID is invalid.
	SQRDAuthorizationErrorInvalidLocationID,
	/// Location is not authorized for card processing
	SQRDAuthorizationErrorLocationNotActivatedForCardProcessing,
	/// LocationID is empty.
	SQRDAuthorizationErrorEmptyLocationID,
	/// Country is not supported
	SQRDAuthorizationErrorUnsupportedCountry,
	/// Unexpected authorization error.
	SQRDAuthorizationErrorUnexpected
};

/// The current state of the SDKs authorization
typedef Enum(NSInteger, SQRDAuthorizationState, "AuthorizationState") {
	/// Reader SDK is not currently authorized with a Square Seller account
	SQRDAuthorizationStateNotAuthorized,
	/// Reader SDK is currently attempting authorization with a Square Seller Account
	SQRDAuthorizationStateAuthorizing,
	/// Reader SDK is currently authorized with a Square Seller Account
	SQRDAuthorizationStateAuthorized
};

/// The card’s brand (such as VISA).
typedef Enum(NSInteger, SQRDCardBrand, "CardBrand") {
	/// The card used was unable to be identified
	SQRDCardBrandUnknown = 0,
	/// Visa
	SQRDCardBrandVisa,
	/// Mastercard
	SQRDCardBrandMastercard,
	/// American Express
	SQRDCardBrandAmericanExpress,
	/// Discover
	SQRDCardBrandDiscover,
	/// Discover Diners
	SQRDCardBrandDiscoverDiners,
	/// JCB
	SQRDCardBrandJcb,
	/// China Union Pay
	SQRDCardBrandChinaUnionPay,
	/// Square Gift Card
	SQRDCardBrandSquareGiftCard,
	/// Square Capital Card
	SQRDCardBrandSquareCapitalCard,
	/// Interac
	SQRDCardBrandInterac,
	/// eftpos
	SQRDCardBrandEftpos,
	/// felica
	SQRDCardBrandFelica,
	/// ebt
	SQRDCardBrandEbt,
	/// The card used was unable to be identifier
	SQRDCardBrandOtherBrand
};

/// The card’s cobrand (such as Afterpay).
typedef Enum(NSInteger, SQRDCardCoBrand, "CardCoBrand") {
	/// The card used was unable to be identified
	SQRDCardCoBrandUnknown = 0,
	/// AfterPay
	SQRDCardCoBrandAfterpay,
	/// No cobrand
	SQRDCardCoBrandNone
};

/// The entry method used to provide a card’s details.
typedef Enum(NSInteger, SQRDCardEntryMethod, "CardEntryMethod") {
	/// The card was swiped through a Square reader or Square stand.
	SQRDCardEntryMethodSwiped = 0,
	/// The card information was keyed manually.
	SQRDCardEntryMethodKeyed,
	/// The card was processed via EMV with a Square reader.
	SQRDCardEntryMethodEmv,
	/// The buyer's card details were already on file with Square.
	SQRDCardEntryMethodOnFile,
	/// The card was processed via a contactless (i.e., NFC) transaction with a Square reader.
	SQRDCardEntryMethodContactless,
	/// The card entry method is unknown.
	SQRDCardEntryMethodUnknown
};

/// The state of a card inside of a reader.
typedef Enum(NSInteger, SQRDCardInsertionStatus, "CardInsertionStatus") {
	/// Indicates a card has been inserted into the reader.
	SQRDCardInsertionStatusInserted,
	/// Indicates no card is currently in the reader.
	SQRDCardInsertionStatusNotInserted,
	/// Indicates card insertion status is unknown (Default for magstripe readers).
	SQRDCardInsertionStatusUnknown
};

/// The status of the card payment.
typedef Enum(NSInteger, SQRDCardPaymentStatus, "CardPaymentStatus") {
	/// The payment status is unknown.
	SQRDCardPaymentStatusUnknown = 0,
	/// The card transaction has been authorized but not yet captured.
	SQRDCardPaymentStatusAuthorized,
	/// The card transaction was authorized and subsequently captured (i.e., completed).
	SQRDCardPaymentStatusCaptured,
	/// The card transaction was authorized and subsequently voided (i.e., canceled)
	SQRDCardPaymentStatusVoided,
	/// The card transaction failed
	SQRDCardPaymentStatusFailed
};

/// Represents a currency
typedef Enum(NSInteger, SQRDCurrency, "Currency") {
	SQRDCurrencyUnknown,
	SQRDCurrencyUSD
};

/// Domain associated with errors relating to SQRDPaymentError
static NSString * _Nonnull const SQRDPaymentErrorDomain = @"ReaderSDK2API.Errors.Payment";

/// Errors relating to a payment failing.
typedef ErrorEnum(SQRDPaymentErrorDomain, SQRDPaymentError, "Errors.Payment") {
	/// Reader SDK could not connect to the network.
	SQRDPaymentErrorNoNetwork = 0,
	/// Reader SDK is not currently authorized with a Square Seller account.
	SQRDPaymentErrorNotAuthorized,
	/// Invalid payment parameters were provided.
	SQRDPaymentErrorInvalidPaymentParameters,
	/// The payment timed out.
	SQRDPaymentErrorTimedOut,
	/// Location permission is needed.
	SQRDPaymentErrorLocationPermissionNeeded,
	/// Payment is already in progress.
	SQRDPaymentErrorPaymentAlreadyInProgress,
	/// Invalid Payment Source Provided
	SQRDPaymentErrorInvalidPaymentSource,
	/// Unexpected Error Returned
	SQRDPaymentErrorUnexpected
};

/// The current status of the payment.
typedef Enum(NSInteger, SQRDPaymentStatus, "PaymentStatus") {
	/// The status is unknown and could not be verified.
	SQRDPaymentStatusUnknown = 0,
	SQRDPaymentStatusInitialized,
	/// The payment is approved.
	SQRDPaymentStatusApproved,
	/// The payment was completed.
	SQRDPaymentStatusCompleted,
	/// The payment was canceled.
	SQRDPaymentStatusCanceled,
	/// The payment failed.
	SQRDPaymentStatusFailed
};

/// A coarse representation of the reader’s battery level.
typedef Enum(NSInteger, SQRDReaderBatteryLevel, "ReaderBatteryLevel") {
	/// Battery is extremely low. Plug in device immediately.
	SQRDReaderBatteryLevelCriticallyLow = 0,
	/// Battery is low.
	SQRDReaderBatteryLevelLow,
	/// Battery is about 50% of it’s full capacity.
	SQRDReaderBatteryLevelMid,
	/// Battery is mostly full.
	SQRDReaderBatteryLevelHigh,
	/// Battery is completely charged.
	SQRDReaderBatteryLevelFull
};

/// Indicates the current connection state of a Reader
typedef Enum(NSInteger, SQRDReaderConnectionStatus, "ReaderConnectionState") {
	/// Reader is not connected.
	SQRDReaderConnectionStatusNotConnected,
	/// Reader attempting a connection to the Square backend.
	SQRDReaderConnectionStatusConnecting,
	/// Reader has a successfully established a connection to the Square backend.
	SQRDReaderConnectionStatusConnected,
	/// Reader has failed to connect to the Square backend. See `.failureInfo` for additional context.
	SQRDReaderConnectionStatusFailedToConnect
};

/// Indicates why a reader might have failed to connect to Square.
typedef Enum(NSInteger, SQRDReaderConnectionFailureReason, "ReaderConnectionFailureReason") {
	/// Generic error.
	SQRDReaderConnectionFailureReasonGenericError = 0,
	/// Network issue connecting to Square servers.
	SQRDReaderConnectionFailureReasonNetworkTransportError,
	/// Timed out communicating with reader while establishing connection.
	SQRDReaderConnectionFailureReasonReaderTimeout,
	/// Timed out connecting to Square servers.
	SQRDReaderConnectionFailureReasonNetworkTimeout,
	/// Square server error occurred.
	SQRDReaderConnectionFailureReasonServerError,
	/// Max readers connected.
	SQRDReaderConnectionFailureReasonMaxReadersConnected,
	/// Connection denied by server, see localized title/description for more information.
	SQRDReaderConnectionFailureReasonDeniedByServer,
	/// An error with the device occurred while attempting to establish a connection.
	SQRDReaderConnectionFailureReasonRevokedByDevice,
	/// Not connected to internet, unable to establish connection.
	SQRDReaderConnectionFailureReasonNotConnectedToInternet,
	/// An unknown error occurred.
	SQRDReaderConnectionFailureReasonUnknown
};

/// Provides a suggestion for how to attempt to recover from a failed connection.
typedef Enum(NSInteger, SQRDReaderConnectionFailureRecoverySuggestion, "ReaderConnectionFailureRecoverySuggestion") {
	/// No suggestion. The `.localizedTitle` and `.localizedDescription` fields may provide more information on how to recover.
	SQRDReaderConnectionFailureRecoverySuggestionNoSuggestion = 0,
	/// The connection issue may be transient and we suggest retrying.
	SQRDReaderConnectionFailureRecoverySuggestionRetry,
	/// Reader failed to connect because the user's account requires activation to process cards.
	SQRDReaderConnectionFailureRecoverySuggestionActivateAccount,
	/// There is a specific issue around your account, reader, or device that may require you to contact Square support.
	SQRDReaderConnectionFailureRecoverySuggestionContactSupport
};

/// Domain associated with errors relating to SQRDReaderFirmwareUpdateError
static NSString * _Nonnull const SQRDReaderFirmwareUpdateErrorDomain = @"ReaderSDK2API.Errors.ReaderFirmwareUpdateError";

/// Error conditions that arise when pairing reader
typedef ErrorEnum(SQRDReaderFirmwareUpdateErrorDomain, SQRDReaderFirmwareUpdateError, "Errors.ReaderFirmwareUpdateError") {
	/// Call to server failed for a required update
	SQRDReaderFirmwareUpdateErrorServerCallFailure,
	/// Firmware has notified that the firmware failed.
	SQRDReaderFirmwareUpdateErrorFirmwareFailure,
	/// Reader disconnected during firmware update and didn't reconnect in time
	SQRDReaderFirmwareUpdateErrorConnectionTimeout,
	/// Firmware update failed for unknown reason.
	SQRDReaderFirmwareUpdateErrorUnknownError
};

/// The hardware model of the reader.
typedef Enum(NSInteger, SQRDReaderModel, "ReaderModel") {
	/// [Square Reader for magstripe](https://squareup.com/shop/hardware/us/en/products/magstripe-reader)
	SQRDReaderModelMagstripe = 0,
	/// [Square Reader for contactless and chip](https://squareup.com/shop/hardware/us/en/products/chip-credit-card-reader-with-nfc)
	SQRDReaderModelContactlessAndChip,
	/// [Square Stand](https://squareup.com/shop/hardware/us/en/products/ipad-pos-stand-credit-card-reader)
	SQRDReaderModelStand,
	/// An unknown Square Reader was connected.
	SQRDReaderModelUnknown
};

/// Indicates changes that can occur within a reader
typedef Enum(NSInteger, SQRDReaderChange, "ReaderChange") {
	/// Indicates a reader's state has changed.
	SQRDReaderChangeStateDidChange,
	/// Indicates the battery level of a reader has updated.
	SQRDReaderChangeBatteryLevelDidChange,
	/// Indicates the battery did begin to charge.
	SQRDReaderChangeBatteryDidBeginCharging,
	/// Indicates the battery is no longer charging.
	SQRDReaderChangeBatteryDidEndCharging,
	/// Indicates the blocking firmware update percentage
	SQRDReaderChangeFirmwareUpdatePercentDidChange,
	/// Indicates the connection state of the device has changed.
	SQRDReaderChangeConnectionStateDidChange,
	/// Indicates the connection to the device has failed and `.state.failureInfo` may have more information.
	SQRDReaderChangeConnectionDidFail,
	/// Indicates the blocking firmware update did fail
	SQRDReaderChangeFirmwareUpdateDidFail,
	/// Indicates a card was inserted.
	SQRDReaderChangeCardInserted,
	/// Indicates a card was removed.
	SQRDReaderChangeCardRemoved
};

/// Domain associated with errors relating to SQRDReaderPairingError
static NSString * _Nonnull const SQRDReaderPairingErrorDomain = @"ReaderSDK2API.Errors.ReaderPairing";

/// Error conditions that arise when pairing reader
typedef ErrorEnum(SQRDReaderPairingErrorDomain, SQRDReaderPairingError, "Errors.ReaderPairing") {
	/// Reader SDK is not currently authorized with a Square Seller account.
	SQRDReaderPairingErrorNotAuthorized,
	/// Reader Pairing not supported in sandbox environment
	SQRDReaderPairingErrorNotSupported,
	/// Pairing did not complete in a reasonable time.
	SQRDReaderPairingErrorTimedOut,
	/// There is already an active pairing in progress.
	SQRDReaderPairingErrorReaderAlreadyPairing,
	/// Reader was unable to pair.
	SQRDReaderPairingErrorFailedToConnect,
	/// The bluetooth connection on the device is disabled.
	SQRDReaderPairingErrorBluetoothDisabled,
	/// The SDK is requiring an update to occur.
	SQRDReaderPairingErrorUpdateRequired,
	/// Bluetooth permission has not been determined.
	SQRDReaderPairingErrorBluetoothPermissionNotDetermined,
	/// Bluetooth permission is restricted.
	SQRDReaderPairingErrorBluetoothPermissionRestricted,
	/// Bluetooth permission has been denied.
	SQRDReaderPairingErrorBluetoothPermissionDenied,
	/// Bluetooth permission is unknown.
	SQRDReaderPairingErrorBluetoothPermissionUnknownCase,
	/// Bluetooth is not supported.
	SQRDReaderPairingErrorBluetoothNotSupported,
	/// Bluetooth is not ready.
	SQRDReaderPairingErrorBluetoothNotReady,
	/// Bluetooth is resetting.
	SQRDReaderPairingErrorBluetoothResetting,
	/**
		Error displayed when pairing info is removed by the OS. To fix this force quit the app and
		then go to iOS bluetooth settings and forget the square reader and then re-pair the Square
		reader.
	*/
	SQRDReaderPairingErrorBondingRemoved,
	/// Bluetooth has encountered an  unknown error.
	SQRDReaderPairingErrorBluetoothUnknownError
};

/// The reader’s state.
typedef Enum(NSInteger, SQRDReaderState, "ReaderState") {
	/**
		The reader is unavailable, but known.
		
		If a reader is not connected to a power supply, the reader may fall asleep and needs to be woken up by pressing the power button.
	*/
	SQRDReaderStateDisconnected = 0,
	/// The reader is actively being connected
	SQRDReaderStateConnecting,
	/// The reader is connected and ready to be used.
	SQRDReaderStateReady,
	/// The reader is being updated and cannot be used.
	SQRDReaderStateUpdatingFirmware,
	/// Connection to the reader failed; forget it and try again. `.connectionState` may contain more details.
	SQRDReaderStateFailedToConnect,
	/// This reader is unusable; contact support.
	SQRDReaderStateDisabled
};

/// The style of how the prompt will display.
typedef Enum(NSInteger, SQRDPresentationStyle, "PresentationStyle") {
	/// Reader SDK will choose an appropriate presentation style based on the current environment. For example, on iPad the payment flow may be displayed as an overlay instead of fullscreen.
	SQRDPresentationStyleAutomatic = 0,
	/// Shows the payment flow over the entire window of the screen.
	SQRDPresentationStyleAlwaysFullscreen
};

/// The alternate payment method that we are attempting to charge.
SwiftName("AlternatePaymentMethod")
@protocol SQRDAlternatePaymentMethod <NSObject>

@required
/// Creates or begin a new payment using a provided Payment Source.
- (BOOL)triggerPaymentWith:(nonnull id<SQRDPaymentSource>)source error:(NSError *_Nullable *_Nullable)error Func("triggerPayment(with:)");

/// The type of the payment that is being presented
@property (nonatomic, readonly) SQRDAlternatePaymentMethodType type;

/// Localized string value of the payment type that is consumer friendly
@property (nonatomic, copy, readonly, nonnull) NSString *name;

@end

/// Manages Square Seller account authorization.
SwiftName("AuthorizationManager")
@protocol SQRDAuthorizationManager

@required
/**
	Authorize the SDK with a Square access token.
	
	@param accessToken A Square access token
	@param locationID The identifier of the location which will be associated with payments processed via the SDK
	@param completionHandler The completion handler called when an authorization finishes with the result of the authorization.
*/
- (void)authorizeWithAccessToken:(nonnull NSString *)accessToken locationID:(nonnull NSString *)locationID completionHandler:(void (^_Nonnull)(NSError *_Nullable))completionHandler DiscardableFunc("authorize(withAccessToken:locationID:completionHandler:)");

@required
/// Deauthorize the Square Seller Account.
- (void)deauthorize DiscardableFunc("deauthorize()");

@required
/**
	Add an observer to be notified if the authorizationState did change
	
	@param authorizationStateObserver the observer to be notified of changes.
*/
- (void)add:(nonnull id<SQRDAuthorizationStatusObservable>)authorizationStateObserver DiscardableFunc("add(_:)");

@required
/**
	Removes the observer to be notified if the authorizationState did change
	
	@param authorizationStateObserver the observer to be notified of changes.
*/
- (void)remove:(nonnull id<SQRDAuthorizationStatusObservable>)authorizationStateObserver DiscardableFunc("remove(_:)");

/// The currently authorized location.
@property (nonatomic, strong, readonly, nullable) id<SQRDLocation>authorizedLocation;

/// The current authorization status.
@property (nonatomic, readonly) SQRDAuthorizationState state;

@end

/// Callback invoked when the authorization status changes
SwiftName("AuthorizationStateObserver")
@protocol SQRDAuthorizationStatusObservable

- (void)authorizationStateDidChange:(SQRDAuthorizationState)authorizationState DiscardableFunc("authorizationStateDidChange(_:)");

@end

/// Callback invoked to notify the application of a change in the available card input methods.
SwiftName("AvailableCardInputMethodsObserver")
@protocol SQRDAvailableCardInputMethodsObserver

- (void)availableCardInputMethodsDidChange:(nonnull SQRDCardInputMethods *)cardInputMethods DiscardableFunc("availableCardInputMethodsDidChange(_:)");

@end

/// The card’s non-confidential details.
SwiftName("Card")
@protocol SQRDCard <NSObject>

/// Unique ID for this card. Generated by Square.
@property (nonatomic, copy, readonly, nullable) NSString *id;

/// The card’s brand (such as VISA).
@property (nonatomic, readonly) SQRDCardBrand cardBrand;

/// The card’s CoBrand (such as Afterpay).
@property (nonatomic, readonly) SQRDCardCoBrand coBrand;

/// The last 4 digits of the card number.
@property (nonatomic, copy, readonly, nullable) NSString *last4;

/// The expiration month of the associated card as an integer between 1 and 12.
@property (nonatomic, readonly) NSUInteger expMonth;

/// The four-digit year of the card’s expiration date.
@property (nonatomic, readonly) NSUInteger expYear;

/// The name of the cardholder.
@property (nonatomic, copy, readonly, nullable) NSString *cardholderName;

/// Dictionary representation of a Card
@property (nonatomic, copy, readonly, nonnull) NSDictionary<NSString *, id> *dictionaryRepresentation;

@end

/// Methods of payments that might be supported by readers
SwiftName("CardInputMethods")
@interface SQRDCardInputMethods : NSObject

- (nonnull instancetype)init:(NSArray<SQRDCardInputMethods *> * _Nonnull)cardInputMethods;;

- (nonnull instancetype)init;;

- (nonnull instancetype)initWithRawValue:(NSInteger)rawValue OBJC_DESIGNATED_INITIALIZER;;

- (BOOL)isEqual:(nullable id)object Func("isEqual(_:)");

/// raw value of the input method.
@property (nonatomic, readonly) NSInteger rawValue;

/// Magnetic strip swiping, as supported by the magstripe reader.
@property (nonatomic, class, readonly, strong, nonnull) SQRDCardInputMethods *swipe;

/// Chip card insertion, or“dip”.
@property (nonatomic, class, readonly, strong, nonnull) SQRDCardInputMethods *chip;

/// NFC contactless payment, or“tap”
@property (nonatomic, class, readonly, strong, nonnull) SQRDCardInputMethods *contactless;

@property (nonatomic, readonly) NSUInteger hash;

@property (nonatomic, readonly, copy, nonnull) NSString *description;

/// Indicates there are no available methods to take a payment.
@property (nonatomic, readonly) BOOL isEmpty;

@end

/// Base type of a source to create a payment with
SwiftName("PaymentSource")
@protocol SQRDPaymentSource

@end

/// Creates a new payment using a Card on File
SwiftName("CardOnFilePaymentSource")
@interface SQRDCardOnFilePaymentSource : NSObject <SQRDPaymentSource>

- (nonnull instancetype)initWithCardID:(nonnull NSString *)cardID Func("init(cardID:)");

- (nonnull instancetype)init SWIFT_UNAVAILABLE;;

+ (nonnull instancetype)new SWIFT_UNAVAILABLE_MSG("-init is unavailable");;

/// The idenitifier of the card on file that we are charging.
@property (nonatomic, copy, readonly, nonnull) NSString *cardID;

@end

/// Details about a successful card payment.
SwiftName("CardPaymentDetails")
@protocol SQRDCardPaymentDetails <NSObject>

/// The status of the card payment.
@property (nonatomic, readonly) SQRDCardPaymentStatus status;

/// Details about the card used in this payment, including the brand and last four digits of the card number.
@property (nonatomic, strong, readonly, nullable) id<SQRDCard>card;

/// The entry method used to provide a card’s details.
@property (nonatomic, readonly) SQRDCardEntryMethod entryMethod;

/// For EMV payments, identifies the EMV application used for the payment.
@property (nonatomic, copy, readonly, nullable) NSString *applicationIdentifier;

/// For EMV payments, the human-readable name of the EMV application used for the payment.
@property (nonatomic, copy, readonly, nullable) NSString *applicationName;

/// Status code returned by the card issuer that describes the payment’s authorization status.
@property (nonatomic, copy, readonly, nullable) NSString *authResultCode;

/// Dictionary representation of a CardPaymentDetails
@property (nonatomic, copy, readonly, nonnull) NSDictionary<NSString *, id> *dictionaryRepresentation;

@end

/// Instructs the SDK to begin a Keyed Payment
SwiftName("KeyedCardPaymentSource")
@interface SQRDKeyedCardPaymentSource : NSObject <SQRDPaymentSource>

- (nonnull instancetype)init OBJC_DESIGNATED_INITIALIZER;;

@end

SwiftName("Location")
@protocol SQRDLocation <NSObject>

@property (nonatomic, readonly, copy, nonnull) NSString *id;

@property (nonatomic, readonly, copy, nonnull) NSString *name;

@property (nonatomic, readonly, copy, nonnull) NSString *mcc;

@property (nonatomic, readonly) SQRDCurrency currency;

@end

/// Represents an amount of money.
SwiftName("MoneyAmount")
@protocol SQRDMoneyAmount <NSObject>

/**
	The amount of money in the smallest denomination of the currency.
	
	For example, when `currencyCode` is `.usd` , the amount is in cents.
*/
@property (nonatomic, readonly) NSUInteger amount;

/// The currency code.
@property (nonatomic, readonly) SQRDCurrency currency;

/// String representation of the object
@property (nonatomic, copy, readonly, nonnull) NSString *description;

@end

SwiftName("Money")
@interface SQRDMoney : NSObject <SQRDMoneyAmount>

- (nonnull instancetype)initWithAmount:(NSUInteger)amount currency:(SQRDCurrency)currency Func("init(amount:currency:)");

- (nonnull instancetype)init SWIFT_UNAVAILABLE;;

+ (nonnull instancetype)new SWIFT_UNAVAILABLE_MSG("-init is unavailable");;

@end

/// Represents an ongoing pairing with Square Reader and provides a way to cancel it
SwiftName("PairingHandle")
@protocol SQRDPairingHandle

@required
/**
	Stop pairing with nearby Square Readers.
	
		* Return value is `true` if a pairing was canceled.
*/
- (BOOL)stop DiscardableFunc("stop()");

@end

/// A representation of a payment. See Payments API for more information.
SwiftName("Payment")
@protocol SQRDPayment <NSObject>

/// The server-side ID for this payment.
@property (nonatomic, copy, readonly, nullable) NSString *id;

/// Timestamp of when the payment was created.
@property (nonatomic, copy, readonly, nonnull) NSDate *createdAt;

/// Timestamp of when the payment was last updated.
@property (nonatomic, copy, readonly, nonnull) NSDate *updatedAt;

/// Indicates the current payment status.
@property (nonatomic, readonly) SQRDPaymentStatus status;

/// The amount of money to accept for this payment, not including `tipMoney` .
@property (nonatomic, strong, readonly, nonnull) id<SQRDMoneyAmount>amountMoney;

/// The amount designated as a tip, in addition to `amountMoney`
@property (nonatomic, strong, readonly, nullable) id<SQRDMoneyAmount>tipMoney;

/// The amount of money the developer is taking as a fee for facilitating the payment on behalf of the seller.
@property (nonatomic, strong, readonly, nullable) id<SQRDMoneyAmount>appFeeMoney;

/// The total money for the payment, including `amountMoney` and `tipMoney` .
@property (nonatomic, strong, readonly, nonnull) id<SQRDMoneyAmount>totalMoney;

/// The location ID to associate with the payment. If not specified, the default location is used.
@property (nonatomic, copy, readonly, nullable) NSString *locationID;

/// Associate a previously created order with this payment
@property (nonatomic, copy, readonly, nullable) NSString *orderID;

/// A user-defined ID to associate with the payment. You can use this field to associate the payment to an entity in an external system. For example, you might specify an order ID that is generated by a third-party shopping cart.
@property (nonatomic, copy, readonly, nullable) NSString *referenceID;

/// The ID of the customer associated with the payment. Required if the `sourceID` refers to a card on file created using the Customers API.
@property (nonatomic, copy, readonly, nullable) NSString *customerID;

/// An optional note to be entered by the developer when creating a payment
@property (nonatomic, copy, readonly, nullable) NSString *note;

/// Non-confidential details about the source. Only populated if the `sourceType` is `CARD` .
@property (nonatomic, strong, readonly, nullable) id<SQRDCardPaymentDetails>cardDetails;

@property (nonatomic, readonly, copy, nonnull) NSDictionary<NSString *, id> *dictionaryRepresentation;

@end

/// Represents an ongoing payment and provides a way to cancel the payment or enter card manually.
SwiftName("PaymentHandle")
@protocol SQRDPaymentHandle

@required
/// Attempts to cancel the active payment. Returns `true` if a payment was canceled.
- (BOOL)cancelPayment DiscardableFunc("cancelPayment()");

/// The associated payment that has begun
@property (nonatomic, strong, readonly, nonnull) id<SQRDPayment>payment;

/// Alternate Payment Methods avaialble to create a Payment
@property (nonatomic, copy, readonly, nonnull) NSArray<id<SQRDAlternatePaymentMethod>> *alternatePaymentMethods;

@end

/// The `SQRDPaymentManager` handles creating a new payment.
SwiftName("PaymentManager")
@protocol SQRDPaymentManager

@required
/**
	Used to start a payment.
	
	@param paymentParameters provide to modify amount, currency and other options found within the V2/Payments endpoint
	@param theme style the payment flow displayed.
	@param viewController The view controller to present the payment flow on-top of
	@param delegate the PaymentManagerDelegate where notifications will be received
	
	@return A  PaymentHandle optionally that can be used to interact with the active payment if it has started successfully
*/
- (nullable id<SQRDPaymentHandle>)startPayment:(nonnull SQRDPaymentParameters *)paymentParameters theme:(nonnull SQRDTheme *)theme from:(nonnull UIViewController *)viewController delegate:(nonnull id<SQRDPaymentManagerDelegate>)delegate DiscardableFunc("startPayment(_:theme:from:delegate:)");

@required
/**
	Add an observer to be notified if the available charge methods have changed.
	
	@param availableCardInputMethodsObserver the observer to be notified of changes.
*/
- (void)add:(nonnull id<SQRDAvailableCardInputMethodsObserver>)availableCardInputMethodsObserver DiscardableFunc("add(_:)");

@required
/**
	Removes the observer to be notified if the available charge methods have changed.
	
	@param availableCardInputMethodsObserver the observer to be removed.
*/
- (void)remove:(nonnull id<SQRDAvailableCardInputMethodsObserver>)availableCardInputMethodsObserver DiscardableFunc("remove(_:)");

/**
	Used to determine the possible charge methods.
	
	@return The possible charge options.
*/
@property (nonatomic, strong, readonly, nonnull) SQRDCardInputMethods *availableCardInputMethods;

@end

/// The delegate provided to a `startPayment` call must adopt the `SQRDPaymentManagerDelegate` protocol
SwiftName("PaymentManagerDelegate")
@protocol SQRDPaymentManagerDelegate

@optional
/**
	This method is called when payment has been started and the an idempotency key has been generated, but no further action has been taken.
	
	@param paymentManager The payment manager.
	@param payment Returns an instance of `SQRDPayment` which contains information about the ongoing payment
*/
- (void)paymentManager:(nonnull id<SQRDPaymentManager>)paymentManager didStart:(nonnull id<SQRDPayment>)payment DiscardableFunc("paymentManager(_:didStart:)");

@required
/**
	This method is called when payment has succeeded and the payment flow has been dismissed. You can now start a new payment.
	
	@param paymentManager The payment manager.
	@param payment The payment.
*/
- (void)paymentManager:(nonnull id<SQRDPaymentManager>)paymentManager didFinish:(nonnull id<SQRDPayment>)payment DiscardableFunc("paymentManager(_:didFinish:)");

@required
/**
	This method is called when a payment error occurs.
	
	@param paymentManager The payment manager. 
	@param error The error that occured. @see `PaymentError` for a list of error codes.
*/
- (void)paymentManager:(nonnull id<SQRDPaymentManager>)paymentManager didFail:(nonnull id<SQRDPayment>)payment withError:(nonnull NSError *)error DiscardableFunc("paymentManager(_:didFail:withError:)");

@required
/**
	This method is called after the payment has been canceled programatically or cancellation has been initiated by the user within the payment flow. You can now start a new payment.
	
	@param paymentManager The payment manager.
*/
- (void)paymentManager:(nonnull id<SQRDPaymentManager>)paymentManager didCancel:(nonnull id<SQRDPayment>)payment DiscardableFunc("paymentManager(_:didCancel:)");

@optional
/**
	Optional - This method is called when payment has succeeded and the payment flow is about to be dismissed. Use this method to prepare your UI before the payment flow is dismissed.
	
	@param paymentManager The payment manager.
	@param payment The completed payment
*/
- (void)paymentManager:(nonnull id<SQRDPaymentManager>)paymentManager willFinish:(nonnull id<SQRDPayment>)payment DiscardableFunc("paymentManager(_:willFinish:)");

@optional
/**
	Optional - This method is called when payment cancellation is about to be completed. If the payment flow has been presented, use this method to prepare your UI before the payment flow is dismissed.
	
	@param paymentManager The payment manager.
*/
- (void)paymentManager:(nonnull id<SQRDPaymentManager>)paymentManager willCancel:(nonnull id<SQRDPayment>)payment DiscardableFunc("paymentManager(_:willCancel:)");

@end

/// Parameters to describe a single payment made using Reader SDK.
SwiftName("PaymentParameters")
@interface SQRDPaymentParameters : NSObject

- (nonnull instancetype)initWithAmountMoney:(nonnull id <SQRDMoneyAmount>)amountMoney Func("init(amountMoney:)");

- (nonnull instancetype)init SWIFT_UNAVAILABLE;;

+ (nonnull instancetype)new SWIFT_UNAVAILABLE_MSG("-init is unavailable");;

/// Timestamp this payment started on device.
@property (nonatomic, copy, readonly, nonnull) NSDate *createdAt;

/**
	If set to true and charging a Square Gift Card, a payment may be returned with `amountMoney` equal to less than what was requested. Example, a request for $20 when charging a Square Gift Card with balance of $5 will result in an `APPROVED` payment of $5. You may choose to prompt the buyer for an additional payment to cover the remainder, or cancel the gift card payment. Cannot be `true` when `autocomplete = true` . For more information, see Partial amount with Square gift cards .
	
	Defaults to `false`
*/
@property (nonatomic, assign, unsafe_unretained, readwrite) BOOL acceptPartialAuthorization;

/// If set to true, this payment will be completed when possible. If set to false, this payment will be held in an approved state until either explicitly completed (captured) or canceled (voided). For more information, see Delayed Payments .
@property (nonatomic, assign, unsafe_unretained, readwrite) BOOL autocomplete;

/**
	The duration of time after the payment’s creation when Square automatically cancels the payment. This automatic cancellation applies only to payments that don’t reach a terminal state ( `COMPLETED` , `CANCELED` , or `FAILED` ) before the `delayDuration` time period.
	
	note:
		This feature is only supported for card payments. This parameter can only be set for a delayed capture payment ( `autocomplete=false` ).The minimum value for this parameter is 1 minute.
*/
@property (nonatomic, copy, readwrite, nullable) NSString *delayDuration;

/// The amount of money to accept for this payment, not including `tipMoney`
@property (nonatomic, strong, readwrite, nonnull) id<SQRDMoneyAmount>amountMoney;

/// The amount designated as a tip, in addition to `amountMoney`
@property (nonatomic, strong, readwrite, nullable) id<SQRDMoneyAmount>tipMoney;

/// The amount of money the developer is taking as a fee for facilitating the payment on behalf of the seller. Cannot be more than 90% of the total amount of the Payment.
@property (nonatomic, strong, readwrite, nullable) id<SQRDMoneyAmount>appFeeMoney;

/**
	Total amount of the payment.
	
	Equal to the sum of `amountMoney` and `tipMoney`
*/
@property (nonatomic, strong, readonly, nonnull) id<SQRDMoneyAmount>totalMoney;

/// The location ID to associate with the payment. If not specified, the default location is used.
@property (nonatomic, copy, readwrite, nullable) NSString *locationId;

/// Associate a previously created order with this payment.
@property (nonatomic, copy, readwrite, nullable) NSString *orderID;

/// A user-defined ID to associate with the payment. You can use this field to associate the payment to an entity in an external system. For example, you might specify an order ID that is generated by a third-party shopping cart
@property (nonatomic, copy, readwrite, nullable) NSString *referenceID;

/// The ID of the customer associated with the payment. This value is required when using a customer’s card on file to create a payment.
@property (nonatomic, copy, readwrite, nullable) NSString *customerID;

/// The ID of the employee associated with the payment.
@property (nonatomic, copy, readwrite, nullable) NSString *employeeId;

/// An optional note to be entered by the developer when creating a payment.
@property (nonatomic, copy, readwrite, nullable) NSString *note;

/// Optional additional payment information to include on the customer’s card statement as part of statement description.
@property (nonatomic, copy, readwrite, nullable) NSString *statementDescriptionIdentifier;

@end

/// The current battery status of a reader.
SwiftName("ReaderBatteryStatus")
@protocol SQRDReaderBatteryStatus <NSObject>

/// A coarse representation of the reader’s battery level
@property (nonatomic, readonly) SQRDReaderBatteryLevel level;

/// The battery percentage of the reader (from 0 to 100)
@property (nonatomic, readonly) NSUInteger percentage;

/// Indicates whether or not the battery is charging
@property (nonatomic, readonly) BOOL isCharging;

@end

/// Provides additional information if the `SQRDReaderConnectionStatus` is `.failedToConnect` .
SwiftName("ReaderConnectionFailureInfo")
@protocol SQRDReaderConnectionFailureInfo <NSObject>

/// Specific failure reason.
@property (nonatomic, readonly) SQRDReaderConnectionFailureReason failureReason;

/// Hint on recovery options while in this failed state.
@property (nonatomic, readonly) SQRDReaderConnectionFailureRecoverySuggestion recoverySuggestion;

/// Localized title for this error suitable to display to a user.
@property (nonatomic, copy, readonly, nonnull) NSString *localizedTitle;

/// Localized description for this error suitable to display to a user.
@property (nonatomic, copy, readonly, nonnull) NSString *localizedDescription;

@end

/// Contains connection information about a Readers current state.
SwiftName("ReaderConnectionInfo")
@protocol SQRDReaderConnectionInfo <NSObject>

/// Indicates the current state of the connection of a reader.
@property (nonatomic, readonly) SQRDReaderConnectionStatus state;

/// Returns information if the connection failed to connect.
@property (nonatomic, strong, readonly, nullable) id<SQRDReaderConnectionFailureInfo>failureInfo;

@end

/// The firmware info of the reader
SwiftName("ReaderFirmwareInfo")
@protocol SQRDReaderFirmwareInfo <NSObject>

/// Indicates the version of the firmware installed on reader
@property (nonatomic, copy, readonly, nonnull) NSString *version;

/// The firmware update percentage of the reader (from 0 to 100)
@property (nonatomic, readonly) NSUInteger updatePercentage;

/// Indicates the failure reason in case the firmware upgrade failed
@property (nonatomic, strong, readonly, nullable) NSError *failureReason;

@end

SwiftName("ReaderInfo")
@protocol SQRDReaderInfo <NSObject>

/// Unique ID for this reader.
@property (nonatomic, readonly) NSUInteger id;

/// Human readable name for this reader.
@property (nonatomic, copy, readonly, nonnull) NSString *name;

/// Serial number of this reader.
@property (nonatomic, copy, readonly, nullable) NSString *serialNumber;

/// Model of this reader.
@property (nonatomic, readonly) SQRDReaderModel model;

/// Set of card input methods this reader can support.
@property (nonatomic, strong, readonly, nonnull) SQRDCardInputMethods *supportedInputMethods;

/// Provides additional context about the connection status of the reader.
@property (nonatomic, strong, readonly, nonnull) id<SQRDReaderConnectionInfo>connectionInfo;

/// Current status of the firmware info.
@property (nonatomic, strong, readonly, nullable) id<SQRDReaderFirmwareInfo>firmwareInfo;

/// The current state of the reader.
@property (nonatomic, readonly) SQRDReaderState state;

/// Current status of the reader battery.
@property (nonatomic, strong, readonly, nullable) id<SQRDReaderBatteryStatus>batteryStatus;

/// True if the reader has lights and supports blinking.
@property (nonatomic, readonly) BOOL canBlink;

/// True if the a reader’s bluetooth connection can be forgotten.
@property (nonatomic, readonly) BOOL canForget;

/// True if the a reader’s session can be retried
@property (nonatomic, readonly) BOOL canRetryConnection;

/// Indicates if the reader has a card inserted.
@property (nonatomic, readonly) SQRDCardInsertionStatus cardInsertionStatus;

@end

/// The `ReaderManagerProtocol` handles interactions with Square card readers, including pairing Bluetooth readers, getting the current set of available readers, and observing changes in available readers.
SwiftName("ReaderManager")
@protocol SQRDReaderManager

@required
/**
	Start pairing with a nearby Square Reader.
	
	Pairing will automatically time out after one minute. Pairing will automatically stop after a reader has been connected. To pair another reader, call this method after the first reader finishes pairing.
	
	@param delegate The object to notify when a reader is paired or fails to pair
	
	@return `SQRDPairingHandle` object to be used to stop the payment if the pairing has started successfully.
*/
- (nullable id<SQRDPairingHandle>)startPairingWith:(nonnull id<SQRDReaderPairingDelegate>)delegate DiscardableFunc("startPairing(with:)");

@required
/// Forget the reader if the reader supports the capability.
- (void)forget:(nonnull id<SQRDReaderInfo>)readerInfo DiscardableFunc("forget(_:)");

@required
/// Blink the reader if the reader supports the capability.
- (void)blink:(nonnull id<SQRDReaderInfo>)readerInfo DiscardableFunc("blink(_:)");

@required
/// Attempts to retry the connection with Square’s servers. Listen for connection state changes in `SQRDReaderObserver`
- (void)retryConnection:(nonnull id<SQRDReaderInfo>)readerInfo DiscardableFunc("retryConnection(_:)");

@required
/**
	Add an observer to be notified of changes to available card readers.
	
	@param readerObserver The object to notify when readers change, are added, or are removed.
*/
- (void)add:(nonnull id<SQRDReaderObserver>)readerObserver DiscardableFunc("add(_:)");

@required
/**
	Remove an observer to stop its being notified of changes to available card readers.
	
	@param readerObserver An existing reader observer to be removed.
*/
- (void)remove:(nonnull id<SQRDReaderObserver>)readerObserver DiscardableFunc("remove(_:)");

/// The array of connected card readers.
@property (nonatomic, copy, readonly, nonnull) NSArray<id<SQRDReaderInfo>> *readers;

/// Indicates pairing has started
@property (nonatomic, readonly) BOOL isPairingInProgress;

@end

/// Callback invoked to notify the application of a change to a single card reader.
SwiftName("ReaderObserver")
@protocol SQRDReaderObserver

@required
/// Indicates a reader was added and made available for use.
- (void)readerWasAdded:(nonnull id<SQRDReaderInfo>)readerInfo DiscardableFunc("readerWasAdded(_:)");

@required
/// Indicates a reader was removed and can no longer be used
- (void)readerWasRemoved:(nonnull id<SQRDReaderInfo>)readerInfo DiscardableFunc("readerWasRemoved(_:)");

@required
/// Indicates a property of the reader has been updated.
- (void)readerDidChange:(nonnull id<SQRDReaderInfo>)readerInfo change:(SQRDReaderChange)change DiscardableFunc("readerDidChange(_:change:)");

@end

/// The delegate provided to a `startPairing` call must adopt the `SQRDReaderPairingDelegate` protocol.
SwiftName("ReaderPairingDelegate")
@protocol SQRDReaderPairingDelegate

@required
/// Indicates that reader pairing started.
- (void)readerPairingDidBegin DiscardableFunc("readerPairingDidBegin()");

@required
/// Indicates that reader pairing was successful.
- (void)readerPairingDidSucceed DiscardableFunc("readerPairingDidSucceed()");

@required
/**
	Indicates that reader pairing failed.
	
	@param error The error indicating why the pairing failed.
*/
- (void)readerPairingDidFailWithError:(nonnull NSError *)error DiscardableFunc("readerPairingDidFail(withError:)");

@end

/**
	Manages initialization for Reader SDK and provides access to the Authorization, Payment and Reader managers
	
	warning:
		You must initialize Reader SDK before attempting any other operation. All methods in this class must be called from the main thread.
*/
SwiftName("SDKManager")
@protocol SQRDSDKManager <NSObject>

/// Manages authorization with the Square seller account.
@property (nonatomic, strong, readonly, nonnull) id<SQRDAuthorizationManager>authorizationManager;

/// Manages pairing new readers and provides access to previously paired readers
@property (nonatomic, strong, readonly, nonnull) id<SQRDReaderManager>readerManager;

/// Manages creating a payment.
@property (nonatomic, strong, readonly, nonnull) id<SQRDPaymentManager>paymentManager;

/// Returns‘true’ if Reader SDK is in Sandbox environment, ‘false’ otherwise.
@property (nonatomic, readonly) BOOL isSandboxEnvironment;

@end

/// Configures the appearance of the Reader SDK payment flow
SwiftName("Theme")
@interface SQRDTheme : NSObject

- (nonnull instancetype)init Func("init()");

- (nonnull instancetype)initWithTitleColor:(nonnull UIColor *)titleColor titleFont:(nonnull UIFont *)titleFont subtitleColor:(nonnull UIColor *)subtitleColor subtitleFont:(nonnull UIFont *)subtitleFont tintColor:(nonnull UIColor *)tintColor backgroundColor:(nonnull UIColor *)backgroundColor buttonTextColor:(nonnull UIColor *)buttonTextColor buttonFont:(nonnull UIFont *)buttonFont buttonCornerRadius:(CGFloat)buttonCornerRadius informationIconColor:(nonnull UIColor *)informationIconColor successIconColor:(nonnull UIColor *)successIconColor errorIconColor:(nonnull UIColor *)errorIconColor cornerRadius:(CGFloat)cornerRadius presentationStyle:(SQRDPresentationStyle)presentationStyle inputFieldColor:(nonnull UIColor *)inputFieldColor inputFieldTextColor:(nonnull UIColor *)inputFieldTextColor inputFieldPlaceholderTextColor:(nonnull UIColor *)inputFieldPlaceholderTextColor inputFieldErrorColor:(nonnull UIColor *)inputFieldErrorColor Func("init(titleColor:titleFont:subtitleColor:subtitleFont:tintColor:backgroundColor:buttonTextColor:buttonFont:buttonCornerRadius:informationIconColor:successIconColor:errorIconColor:cornerRadius:presentationStyle:inputFieldColor:inputFieldTextColor:inputFieldPlaceholderTextColor:inputFieldErrorColor:)");

- (BOOL)isEqual:(nullable id)object Func("isEqual(_:)");

/// The color of the title label.
@property (nonatomic, strong, readwrite, nonnull) UIColor *titleColor;

/// The font of the title label.
@property (nonatomic, strong, readwrite, nonnull) UIFont *titleFont;

/// The color of the subtitle label.
@property (nonatomic, strong, readwrite, nonnull) UIColor *subtitleColor;

/// The font of the subtitle label.
@property (nonatomic, strong, readwrite, nonnull) UIFont *subtitleFont;

/**
	The tint color currently reflected in:
	
		* The primary action buttons background color
*/
@property (nonatomic, strong, readwrite, nonnull) UIColor *tintColor;

/// Background color of the payment flow that is displayed.
@property (nonatomic, strong, readwrite, nonnull) UIColor *backgroundColor;

/// Text color of the primary action button
@property (nonatomic, strong, readwrite, nonnull) UIColor *buttonTextColor;

/// Font of the primary action button
@property (nonatomic, strong, readwrite, nonnull) UIFont *buttonFont;

/// Corner radius of the primary action button.
@property (nonatomic, assign, unsafe_unretained, readwrite) CGFloat buttonCornerRadius;

/// Tint color used on informative icons
@property (nonatomic, strong, readwrite, nonnull) UIColor *informationIconColor;

/// Tint color used on success icons
@property (nonatomic, strong, readwrite, nonnull) UIColor *successIconColor;

/// Tint color used on error icons
@property (nonatomic, strong, readwrite, nonnull) UIColor *errorIconColor;

/// Corner radius of the prompt that is displayed.
@property (nonatomic, assign, unsafe_unretained, readwrite) CGFloat cornerRadius;

/// Presentation style of the payment flow.
@property (nonatomic, assign, unsafe_unretained, readwrite) SQRDPresentationStyle presentationStyle;

/// Background color used on input fields
@property (nonatomic, strong, readwrite, nonnull) UIColor *inputFieldColor;

/// Text color used on input fields
@property (nonatomic, strong, readwrite, nonnull) UIColor *inputFieldTextColor;

/// Color used for placeholdertext on input fields
@property (nonatomic, strong, readwrite, nonnull) UIColor *inputFieldPlaceholderTextColor;

/// Color used for errors shown for input fields
@property (nonatomic, strong, readwrite, nonnull) UIColor *inputFieldErrorColor;

@property (nonatomic, readonly) NSUInteger hash;

@end

/// Generates a currency from a ISO 4217 currency code RENAME_FUNC(Currency.init(_:))
enum SQRDCurrency SQRDCurrencyFromCurrencyCode(NSString * _Nonnull string) SWIFT_WARN_UNUSED_RESULT SwiftName("Currency.init(_:)");

/// The raw description of the card brand. RENAME_FUNC(getter:AuthorizationState.description(self:))
NSString * _Nonnull SQRDStringFromAuthorizationState(enum SQRDAuthorizationState authorizationState) SWIFT_WARN_UNUSED_RESULT SwiftName("getter:AuthorizationState.description(self:)");

/// The raw description of the card brand. RENAME_FUNC(getter:CardBrand.description(self:))
NSString * _Nonnull SQRDStringFromCardBrand(enum SQRDCardBrand cardBrand) SWIFT_WARN_UNUSED_RESULT SwiftName("getter:CardBrand.description(self:)");

/// The raw description of the card cobrand. RENAME_FUNC(getter:CardCoBrand.description(self:))
NSString * _Nonnull SQRDStringFromCardCoBrand(enum SQRDCardCoBrand coBrand) SWIFT_WARN_UNUSED_RESULT SwiftName("getter:CardCoBrand.description(self:)");

/// The raw description of the card entry method. RENAME_FUNC(getter:CardEntryMethod.description(self:))
NSString * _Nonnull SQRDStringFromCardEntryMethod(enum SQRDCardEntryMethod cardEntryMethod) SWIFT_WARN_UNUSED_RESULT SwiftName("getter:CardEntryMethod.description(self:)");

/// The raw description of the payment status. RENAME_FUNC(getter:CardPaymentStatus.description(self:))
NSString * _Nonnull SQRDStringFromCardPaymentStatus(enum SQRDCardPaymentStatus cardPaymentStatus) SWIFT_WARN_UNUSED_RESULT SwiftName("getter:CardPaymentStatus.description(self:)");

/// Gets the corresponding ISO 4217 currency code RENAME_FUNC(getter:Currency.currencyCode(self:))
NSString * _Nonnull SQRDCurrencyCodeFromCurrency(enum SQRDCurrency currency) SWIFT_WARN_UNUSED_RESULT SwiftName("getter:Currency.currencyCode(self:)");

/// Raw description of the current payment status. RENAME_FUNC(getter:PaymentStatus.description(self:))
NSString * _Nonnull SQRDStringFromPaymentStatus(enum SQRDPaymentStatus paymentStatus) SWIFT_WARN_UNUSED_RESULT SwiftName("getter:PaymentStatus.description(self:)");

/// Raw description of the current state of the reader. RENAME_FUNC(getter:ReaderState.description(self:))
NSString * _Nonnull SQRDStringFromReaderState(enum SQRDReaderState readerState) SWIFT_WARN_UNUSED_RESULT SwiftName("getter:ReaderState.description(self:)");

#undef ErrorEnum
#undef SWIFT_UNAVAILABLE_MSG
#undef SWIFT_UNAVAILABLE
#undef OBJC_DESIGNATED_INITIALIZER
#undef Enum
#undef SwiftName
#undef DiscardableFunc
#undef Func
#undef RuntimeName
#undef SWIFT_WARN_UNUSED_RESULT
#pragma clang attribute pop
#pragma clang diagnostic pop
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wignored-attributes"
#pragma clang attribute push(__attribute__((objc_subclassing_restricted)), apply_to=any(objc_interface))
#define SWIFT_WARN_UNUSED_RESULT __attribute__((warn_unused_result))
#define RuntimeName(RUNTIMENAME) __attribute__((objc_runtime_name(RUNTIMENAME)))
#define Func(X) __attribute__((swift_name(X))) __attribute__((warn_unused_result))
#define DiscardableFunc(X) __attribute__((swift_name(X)))
#define SwiftName(X) __attribute__((swift_name(X)))
#define Enum(TYPE, CNAME, SNAME) NS_CLOSED_ENUM(TYPE, __attribute__((swift_name(SNAME))) CNAME)
#define SWIFT_UNAVAILABLE_MSG(msg) __attribute__((unavailable(msg)))
#define SWIFT_UNAVAILABLE __attribute__((unavailable))
# define OBJC_DESIGNATED_INITIALIZER __attribute__((objc_designated_initializer))
#define ErrorEnum(DOMAIN, CNAME, SNAME) NS_CLOSED_ENUM(NSInteger, __attribute__((ns_error_domain(DOMAIN))) __attribute__((swift_name(SNAME))) CNAME)

@class NSString;
@class SQRDReaderSDK;
@protocol SQRDSDKManager;

/**
	Manages initialization for Reader SDK and provides access to the Authorization, Payment and Reader managers
	
	warning:
		You must initialize Reader SDK before attempting any other operation. All methods in this class must be called from the main thread. You cannot initalize Reader SDK multiple times.
*/
SwiftName("ReaderSDK")
@interface SQRDReaderSDK : NSObject

/**
	Initializes Reader SDK. Call this method from the `application:didFinishLaunchingWithOptions:` method in your AppDelegate.
	
	warning:
		You must initialize Reader SDK before attempting any other operation. All methods in this class must be called from the main thread. You cannot initalize Reader SDK multiple times.
*/
+ (void)initializeWithApplicationLaunchOptions:(nullable NSDictionary *)applicationLaunchOptions squareApplicationID:(nonnull NSString *)squareApplicationID DiscardableFunc("initialize(applicationLaunchOptions:squareApplicationID:)");

- (nonnull instancetype)init Func("init()");

+ (nonnull instancetype)new SWIFT_UNAVAILABLE_MSG("-init is unavailable");;

@property (nonatomic, class, readonly, strong, nonnull) id <SQRDSDKManager>shared;

@end

#undef ErrorEnum
#undef SWIFT_UNAVAILABLE_MSG
#undef SWIFT_UNAVAILABLE
#undef OBJC_DESIGNATED_INITIALIZER
#undef Enum
#undef SwiftName
#undef DiscardableFunc
#undef Func
#undef RuntimeName
#undef SWIFT_WARN_UNUSED_RESULT
#pragma clang attribute pop
#pragma clang diagnostic pop
