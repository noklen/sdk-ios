#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wignored-attributes"
#pragma clang attribute push(__attribute__((objc_subclassing_restricted)), apply_to=any(objc_interface))
#define SWIFT_WARN_UNUSED_RESULT __attribute__((warn_unused_result))
#define RuntimeName(RUNTIMENAME) __attribute__((objc_runtime_name(RUNTIMENAME)))
#define Func(X) __attribute__((swift_name(X))) __attribute__((warn_unused_result))
#define DiscardableFunc(X) __attribute__((swift_name(X)))
#define SwiftName(X) __attribute__((swift_name(X)))
#define Enum(TYPE, CNAME, SNAME) NS_CLOSED_ENUM(TYPE, __attribute__((swift_name(SNAME))) CNAME)
#define SWIFT_UNAVAILABLE_MSG(msg) __attribute__((unavailable(msg)))
#define SWIFT_UNAVAILABLE __attribute__((unavailable))
# define OBJC_DESIGNATED_INITIALIZER __attribute__((objc_designated_initializer))
#define ErrorEnum(DOMAIN, CNAME, SNAME) NS_CLOSED_ENUM(NSInteger, __attribute__((ns_error_domain(DOMAIN))) __attribute__((swift_name(SNAME))) CNAME)

@class NSNumber;
@class SQRDMockReaderUI;
@class SQRDTheme;
@protocol SQRDSDKManager;

/// OBJC_NAMESPACE
typedef Enum(NSInteger, __swift_namespace_MockErrors, "MockErrors") {
__ignore_me_MockErrors
};

/// Domain associated with errors relating to SQRDMockReaderUIError
static NSString * _Nonnull const SQRDMockReaderUIErrorDomain = @"MockReaderUI.MockErrors.MockReaderUI";

/// Errors that occur when initialization of MockReaderUI SDK fails.
typedef ErrorEnum(SQRDMockReaderUIErrorDomain, SQRDMockReaderUIError, "MockErrors.MockReaderUI") {
	/// The version provided for ReaderSDK & MockReaderUI do not match.
	SQRDMockReaderUIErrorVersionMismatch,
	/// The SDK was initialized in a non-sandbox environment.
	SQRDMockReaderUIErrorInvalidApplicationId,
	/// Unexpected initialization error.
	SQRDMockReaderUIErrorUnexpected,
	/// Attempted presentation of the mock reader when unauthorized
	SQRDMockReaderUIErrorNotAuthorized,
	/// No scene exists to attach the floating mock reader window. This error only affects scene-based apps.
	SQRDMockReaderUIErrorNoScene
};

/**
	Handles displaying and hiding a floating action button that can be used with a Square sandbox applicationId to simulate a magstripe or contactless reader.
	
		* Keep a strong reference to an instance of `SQRDMockReaderUI` .
		* Ensure you are using sandbox square applicationID.
		* Call `present()` to show the floating action button.
		* Call `dismiss()` to hide the floating action button.
*/
SwiftName("MockReaderUI")
@interface SQRDMockReaderUI : NSObject

/**
	Initialize a new instance of `SQRDMockReaderUI`
	
	@param readerSDK The SDK manager for the mock reader UI to use. In most cases this is `ReaderSDK.shared` .
*/
- (nullable instancetype)initFor:(nonnull id<SQRDSDKManager>)readerSDK error:(NSError *_Nullable *_Nullable)error Func("init(for:)");

/**
	Initialize a new instance of `SQRDMockReaderUI`
	
	@param readerSDK The SDK manager for the mock reader UI to use. In most cases this is `ReaderSDK.shared` .
	@param theme Instance of `Theme` used to customize the appearance of the UI
*/
- (nullable instancetype)initFor:(nonnull id<SQRDSDKManager>)readerSDK theme:(nonnull SQRDTheme *)theme error:(NSError *_Nullable *_Nullable)error Func("init(for:theme:)");

/**
	Displays a floating action button on top of the application’s UI.
	
	This will only be visible if ReaderSDK is configured to run with a Square sandbox applicationId.
*/
- (BOOL)presentAndReturnError:(NSError *_Nullable *_Nullable)error Func("present()");

/// Hides the floating action button.
- (void)dismiss DiscardableFunc("dismiss()");

- (nonnull instancetype)init SWIFT_UNAVAILABLE;;

+ (nonnull instancetype)new SWIFT_UNAVAILABLE_MSG("-init is unavailable");;

/**
	Property returning the state of the mock reader UI.
	
	Returns `true` if the floating action button is visible, `false` if hidden.
*/
@property (nonatomic, readonly) BOOL isPresented;

@end

#undef ErrorEnum
#undef SWIFT_UNAVAILABLE_MSG
#undef SWIFT_UNAVAILABLE
#undef OBJC_DESIGNATED_INITIALIZER
#undef Enum
#undef SwiftName
#undef DiscardableFunc
#undef Func
#undef RuntimeName
#undef SWIFT_WARN_UNUSED_RESULT
#pragma clang attribute pop
#pragma clang diagnostic pop
