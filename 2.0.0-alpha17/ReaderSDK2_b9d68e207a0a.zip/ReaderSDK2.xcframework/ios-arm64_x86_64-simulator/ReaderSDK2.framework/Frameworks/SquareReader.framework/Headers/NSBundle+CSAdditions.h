//
//  NSBundle+CSAdditions.h
//  CoreSwipe
//
//  Created by Eric Firestone on 8/15/12.
//  Copyright (c) 2013 Square, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSBundle (CSAdditions)

+ (NSBundle *)coreSwipeResourcesBundle;

@end
