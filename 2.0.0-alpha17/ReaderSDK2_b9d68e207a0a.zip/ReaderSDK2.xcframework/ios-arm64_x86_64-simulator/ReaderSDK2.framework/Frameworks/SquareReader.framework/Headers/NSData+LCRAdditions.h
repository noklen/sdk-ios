//
//  NSData+LCRAdditions.h
//  Pods
//
//  Created by Jordan McAdoo on 7/13/23.
//

@import Foundation;


@interface NSData (LCR_NSData)

#pragma mark - String Conversion
- (NSString *)sqr_hexString;

@end
